CREATE TABLE tb_fornecedor(

id_fornecedor int zerofill unsigned auto_increment not null,
nm_fornecedor varchar(40) unique not null,
cnpj_fornecedor varchar(19) unique not null,
end_fornecedor varchar(40) not null,
tl_fornecedor varchar(10) not null,
email_fornecedor varchar(40) not null,


constraint pk_fornecedor primary key (id_fornecedor)


)