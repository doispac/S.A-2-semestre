create table tb_categoria (

id_categoria int auto_increment not null,
nm_categoria  varchar(40) unique,

constraint pk_categoria primary key (id_categoria )
)