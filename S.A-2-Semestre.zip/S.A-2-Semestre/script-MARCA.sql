create table tb_marca (

id_marca int auto_increment not null,
nm_marca varchar(40) unique,

constraint pk_marca primary key (id_marca)

)
