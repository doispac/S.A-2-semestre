create table tb_produto (

id_produto int auto_increment not null,
nm_produto varchar(40) not null,
qt_produto decimal(10,2)not null, 
vl_produto decimal(10,2) not null,
ds_produto varchar(400),
id_categoria int not null,
id_marca int unsigned not null,
id_fornecedor int unsigned not null,


constraint pk_produto primary key (id_produto),
constraint fk_categoria foreign key (id_categoria) REFERENCES tb_categoria(id_categoria),
constraint fk_marca foreign key (id_marca) REFERENCES tb_marca(id_marca),
constraint fk_fornecedor foreign key (id_fornecedor) REFERENCES tb_fornecedor(id_fornecedor)
)