create table tb_usuario(
id_usuario int zerofill unsigned auto_increment not null, 
nm_usuario varchar(40) not null,
end_usuario varchar(40) not null,
tl_usuario varchar(10) not null,
email_usuario varchar(40) not null,
cpf_usuario varchar (14) not null,
dat_nasc_usuario date,
login_usuario varchar(40) not null,
senha_usuario varchar(40) not null,

constraint pk_usuario PRIMARY KEY(id_usuario)

)